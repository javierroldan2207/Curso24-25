package com.model;

public class Circulo {
	
	private double radio;


	public Circulo() {
		super();
		this.radio = 1;
	}
	
	  public Circulo(double radio) {
	        if (radio <= 0) {
	            throw new IllegalArgumentException("El radio debe ser mayor que 0");
	        }
	        this.radio = radio;
	    }

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}
	
	public double calcularRadio() {
		return (this.radio * this.radio) * 3.14;
	}
	
    public double calcularPerimetro() {
        return 2 * 3.14 * this.radio ;  
    }

	
	

}
