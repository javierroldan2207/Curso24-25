package com;

import com.model.Circulo;

public class principal {

	public static void main(String[] args) {
		
		Circulo circulo = new Circulo(3);
		
		System.out.println(circulo.calcularRadio());
		System.out.println(circulo.calcularPerimetro());
	}

}
