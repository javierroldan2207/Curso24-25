package com.model;

public class Cancion {
	
	private String titulo;
	private String artista;
	private double duracion;
	private String disco;
	private int año;
	private int nReproducciones;
	
	public Cancion(String titulo, String artista, double duracion, String disco, int año, int nReproducciones) {
		super();
		this.titulo = titulo;
		this.artista = artista;
		this.duracion = duracion;
		this.disco = disco;
		this.año = año;
		this.nReproducciones = nReproducciones;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getArtista() {
		return artista;
	}

	public void setArtista(String artista) {
		this.artista = artista;
	}

	public double getDuracion() {
		return duracion;
	}

	public void setDuracion(double duracion) {
		this.duracion = duracion;
	}

	public String getDisco() {
		return disco;
	}

	public void setDisco(String disco) {
		this.disco = disco;
	}

	public int getAño() {
		return año;
	}

	public void setAño(int año) {
		this.año = año;
	}

	public int getnReproducciones() {
		return nReproducciones;
	}

	public void setnReproducciones(int nReproducciones) {
		this.nReproducciones = nReproducciones;
	}
	

}
