package com.model;

public class Usuario {

	private String nombre;
	private String correo;
	private String clave;
	private boolean premium;
	private ListaReproducciones[]listaReproduccion;
	private int cantListas;
	
	public Usuario(String nombre, String correo, String clave, boolean premium, ListaReproducciones[] listaReproduccion,
			int cantListas) {
		super();
		this.nombre = nombre;
		this.correo = correo;
		this.clave = clave;
		this.premium = premium;
		this.listaReproduccion = listaReproduccion;
		this.cantListas = 0;
	}
	
}
