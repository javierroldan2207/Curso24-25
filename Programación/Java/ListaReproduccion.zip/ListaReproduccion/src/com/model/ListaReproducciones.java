package com.model;

public class ListaReproducciones {
	
	private String nombre;
	private Usuario usuario;
	private int nReproduciones;
	private String fechaCreacion;
	private String fechaUltimaReproduccion;
	private Cancion[] canciones;
	private int cantCanciones;
	
	public ListaReproducciones(String nombre, Usuario usuario, int nReproduciones, String fechaCreacion,
			String fechaUltimaReproduccion, Cancion[] canciones, int cantCanciones) {
		super();
		this.nombre = nombre;
		this.usuario = usuario;
		this.nReproduciones = 0;
		this.fechaCreacion = fechaCreacion;
		this.fechaUltimaReproduccion = fechaUltimaReproduccion;
		this.canciones = canciones;
		this.cantCanciones = 0;
	}
	
	public void agregarcancion(Cancion cancion) {
		  if (cantCanciones < canciones.length) {
	            canciones[cantCanciones] = cancion;
	            cantCanciones++;
	            System.out.println("Canción añadida: " + cancion.getTitulo());
	        } else {
	            System.out.println("No hay espacio para más canciones.");
	        }
	}
}
