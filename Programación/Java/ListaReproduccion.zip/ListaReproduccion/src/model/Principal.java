package model;

import com.model.Cancion;
import com.model.ListaReproducciones;

public class Principal {

	public static void main(String[] args) {
		
		
        ListaReproducciones miLista = new ListaReproducciones("Mi Lista", "Usuario1", "2025-02-11", 3);

        Cancion cancion2 = new Cancion("Canción 2", "Artista 2", 4.0, "Disco 2", 2021, 200);
        Cancion cancion1 = new Cancion("Canción 1", "Artista 1", 3.5, "Disco 1", 2020, 100);
        
        

	}9

}
