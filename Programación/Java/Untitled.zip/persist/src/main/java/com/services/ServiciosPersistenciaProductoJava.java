package main.java.com.services;

import org.hibernate.Session;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Producto;

public class ServiciosPersistenciaProductoJava {
	
	
	void persistir() {
		Session session = ConnectionUtil.getSessionFactory().openSession();
				
	}
	
	
	public void obtener() {
		
		Session session= ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		var producto = session.find(Producto.class, 1L);
		
		assert(producto!=null && producto.getId()==1L);
		session.close();
	}

}
