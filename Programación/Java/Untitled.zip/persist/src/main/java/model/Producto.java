package main.java.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Producto {
	
	@Id
	@GeneratedValue(strategy  = GenerationType.AUTO)
	private long id;
	
	@Column
	private String nombre;
	
	@Column
	private String descripcion;
	
	@Column
	private LocalDate fechaAlta;
	
	@Column
	private LocalDate FechaBaja;
	
	public Producto(long id) {
		super();
		this.id = id;
	}

	public long getId() {
		// TODO Auto-generated method stub
		return this.id;
	}
}
