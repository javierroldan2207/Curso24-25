package main.java;

import org.hibernate.SessionFactory;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Producto;

public class Principal {

	public static void main(String[] args) {
		SessionFactory sf = ConnectionUtil.getSessionFactory(); 
		
		Producto p1 = new Producto(1L);	
		
		
	}
	
	

}