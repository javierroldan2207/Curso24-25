package ejercicios;

public class CoetaneosJRD {

	public static void main(String[] args) {
		int [] fecha1 = {1756,1791};
		int [] fecha2 = {1706,1790};
		System.out.println(coincidenVivos(fecha1,fecha2));
		int [] f1 = {1756,1791}; 
		int [] f2 = {1770,1827}; 
		System.out.println(coincidenVivos(f1,f2));
		int [] pr1 = {100,1791}; 
		System.out.println(coincidenVivos(pr1,f2));
		System.out.println(coincidenVivos(fecha2,pr1));
		
		int [] n1 = {0,5661};
		System.out.println(coincidenVivos(n1,fecha1));
		
		int [] fe1 = {1706,1790};
		int [] fe2 = {1642,1727};
		System.out.println(coincidenVivos(fe1,fe2));

	}
	
	public static int coincidenVivos(int [] fecha1, int [] fecha2) {
		
		int resultado = 0;
		if (fecha1[0] > 1 && fecha2[0] > 1 && fecha1[1] < 1900 && fecha2[1] < 1900) {
			if (fecha1[1]-fecha1[0] < 100 && fecha2[1]-fecha2[0] < 100) {				
				if (fecha1[0] <= fecha2[0]) {
					resultado = (fecha1[1]-fecha2[0])+1;
				}else if (fecha1[0]>=fecha2[0]){
					resultado = fecha2[1]-fecha1[0]+1;
				}
			}
		}
		return resultado;
	}

}
