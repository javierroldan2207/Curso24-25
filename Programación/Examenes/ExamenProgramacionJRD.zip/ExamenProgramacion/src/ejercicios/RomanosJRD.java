package ejercicios;

public class RomanosJRD {

	public static void main(String[] args) {
		System.out.println(SumaNumerosRomanos(sumaNumero1("DV"),sumaNumero2("CVIII")));
		System.out.println(SumaNumerosRomanos(sumaNumero1("CVIII"),sumaNumero2("DV")));
		System.out.println(SumaNumerosRomanos(sumaNumero1("D"),sumaNumero2("C")));
		System.out.println(SumaNumerosRomanos(sumaNumero1(""),sumaNumero2("C")));
		System.out.println(SumaNumerosRomanos(sumaNumero1(" "),sumaNumero2("")));
		System.out.println(SumaNumerosRomanos(sumaNumero1(""),sumaNumero2(" ")));

	}
	
	public static int sumaNumero1(String letras) {
		
		int [] numeros = {1,5,10,50,100,500,1000};
		String [] caracter = {"I","V","X","L","C","D","M"};
		int suma = 0;
		String [] let = letras.split("");
		for (int i = 0; i < letras.length(); i++) {
			for (int j = 0; j < caracter.length; j++) {
				if (let[i].equals(caracter[j])) {
					suma += numeros[j];
				}
			}
		}
		return suma;
	}
	
	public static int sumaNumero2(String letras) {
		
		int [] numeros = {1,5,10,50,100,500,1000};
		String [] caracter = {"I","V","X","L","C","D","M"};
		int suma = 0;
		String [] let = letras.split("");
		for (int i = 0; i < letras.length(); i++) {
			for (int j = 0; j < caracter.length; j++) {
				if (let[i].equals(caracter[j])) {
					suma += numeros[j];
				}
			}
		}
		return suma;
	}
	public static int SumaNumerosRomanos( int numero1, int numero2) {
		
		return numero1+numero2;
		
	}
}

